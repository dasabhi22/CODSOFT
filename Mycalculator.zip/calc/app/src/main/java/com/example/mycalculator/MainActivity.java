package com.example.mycalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText displayEditText;
    private String currentExpression = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        displayEditText = findViewById(R.id.displayEditText);
    }

    public void onDigitClick(View view) {
        Button button = (Button) view;
        String buttonText = button.getText().toString();
        currentExpression += buttonText;
        displayEditText.setText(currentExpression);
    }

    public void onOperatorClick(View view) {
        Button button = (Button) view;
        String buttonText = button.getText().toString();
        currentExpression += " " + buttonText + " ";
        displayEditText.setText(currentExpression);
    }

    public void onDecimalClick(View view) {
        if (!currentExpression.contains(".")) {
            currentExpression += ".";
            displayEditText.setText(currentExpression);
        }
    }

    public void onClearClick(View view) {
        currentExpression = "";
        displayEditText.setText("");
    }

    public void onEqualsClick(View view) {
        try {
            double result = evaluateExpression();
            currentExpression = Double.toString(result);
            displayEditText.setText(currentExpression);
        } catch (Exception e) {
            currentExpression = "";
            displayEditText.setText("Error");
        }
    }

    private double evaluateExpression() {
        String[] tokens = currentExpression.split(" ");
        double result = Double.parseDouble(tokens[0]);
        char operator = ' ';

        for (int i = 1; i < tokens.length; i++) {
            if (i % 2 == 1) {
                operator = tokens[i].charAt(0);
            } else {
                double num = Double.parseDouble(tokens[i]);

                switch (operator) {
                    case '+':
                        result += num;
                        break;
                    case '-':
                        result -= num;
                        break;
                    case '*':
                        result *= num;
                        break;
                    case '/':
                        result /= num;
                        break;
                }
            }
        }
        return result;
    }
}

